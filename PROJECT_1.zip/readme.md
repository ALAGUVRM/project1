Movie-Trailer-Website

This project will build a Movie Trailer Website where users can see my favorite movies and watch the trailers. 
The code stores a list of movie titles, poster images, and movie trailer URLs. 
This information is displayed on a web page and allow users to review the movies and watch the trailers.

Required Library (Version of Python used)

This Movie Trailer Website Project consists of 3 Python version 2.7.13 files that store a list of movies titles, 
along with its respective box movie trailer website. 

How To Run The Application

Using the Terminal:
Type python entertainment_center.py	
Using the Python IDLE:
Select Run from the IDLE menu,
Click Run Module from the dropdown list


IT'S INCLUDED
-media.py
-entertainment_center.py
-fresh_tomatoes.py
-fresh_tomatoes.html
-README.txt


CREATOR
MS.ALAGAMMAI
Prusuing B.E Computer Science Engneering 
From Kgisl Institute of Technology
Contact : 9842878770
E-mail:alagammai1233@gmail.com