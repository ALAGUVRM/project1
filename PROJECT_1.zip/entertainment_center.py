import fresh_tomatoes
import media

# singam movie: moviename,storyline,movie poster,youtube trailer url
singam = media.Movie('singam',
                     "thrilling movie",
                     "https://upload.wikimedia.org/wikipedia/en/8/87/Singam_3_poster.jpg",   # noqa
                     'https://www.youtube.com/watch?v=j-V3Ojg3SNs')

# nanban: moviename,storyline,movie poster,youtube url
nanban = media.Movie("nanban",
                     "comdey movie",
                     "https://upload.wikimedia.org/wikipedia/en/3/33/Nanban_film.jpg",   # noqa
                     "https://www.youtube.com/watch?v=Oqb0Bb6lF9k")

# sivaji : movie name,story line,movie poster,youtube url
sivaji = media.Movie("sivaji",
                     "entertainment movie",
                     "https://upload.wikimedia.org/wikipedia/en/c/ce/Sivaji_The_Boss.jpg",   # noqa
                     "https://www.youtube.com/watch?v=J2GXBLVZk60")

# set  the movies that pass to the media file
movies = [singam, nanban, sivaji]

# Open the HTML file in a webbrowser via freshtomatoes.py file
fresh_tomatoes.open_movies_page(movies)
